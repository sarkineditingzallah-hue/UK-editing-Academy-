# UK Editing Academy — V60 Android Testing Project

This is the real Flutter/Firebase-ready project structure for the UK Editing Academy app.

## Included
- Firebase Email/Password login and registration
- Firestore `users` profile creation
- Student dashboard
- Courses and 20-lesson structure
- Lesson and quiz flow
- Certificates screen
- Notifications screen
- Student profile and logout
- Black / blue / purple / gold academy theme

## Firebase setup
1. Install Flutter and Android Studio on a computer.
2. From this project run `flutter pub get`.
3. Install FlutterFire CLI and run `flutterfire configure` for your Firebase project.
4. This generates `lib/firebase_options.dart` (intentionally not included because it is project-specific).
5. Register Android package `com.ukea.app` in Firebase.
6. Put the downloaded `google-services.json` inside `android/app/` after creating the Android platform with `flutter create .`.
7. Ensure Firebase Authentication → Email/Password is enabled and Firestore is created.
8. Run `flutter run` to test on an Android device/emulator.
9. Build with `flutter build apk --release` when testing is complete.

## Important security
- Never put passwords, OTPs, card numbers, PINs, private keys, or service-account keys in this project or Firestore.
- Student roles and admin authorization should be enforced server-side (custom claims / secure rules), not by a user-editable Firestore field.
- Payment is intentionally not implemented as direct card collection. Use a secure payment provider later with adult/business oversight.
