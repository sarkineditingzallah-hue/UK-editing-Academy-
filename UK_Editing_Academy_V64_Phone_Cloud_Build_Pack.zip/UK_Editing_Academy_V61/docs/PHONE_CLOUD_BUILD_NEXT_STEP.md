# UK Editing Academy — Cloud Build (Phone-Only)

An Android build workflow has been prepared so the project can be built in a cloud CI environment instead of requiring a computer owned by the project owner.

## What is ready
- Package ID target: `com.ukea.app`
- Release artifact: Android App Bundle (`.aab`)
- Debug artifact: Android APK (`.apk`)
- Flutter stable build workflow
- Firebase native Android initialization
- Google Services plugin setup

## One required Firebase file
Place the Firebase Android configuration file at:

`android/app/google-services.json`

This is the non-secret Firebase app configuration file. Do **not** upload passwords, OTPs, PINs, private keys, or bank details.

## Important
The AAB produced by this workflow is a build artifact, not a Play Store publication. Publication still requires an adult-owned Google Play Console developer account and Google's testing/review requirements.
