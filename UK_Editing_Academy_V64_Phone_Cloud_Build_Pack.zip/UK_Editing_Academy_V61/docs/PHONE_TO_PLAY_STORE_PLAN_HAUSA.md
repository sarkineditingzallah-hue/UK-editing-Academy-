# Hanyar daga waya zuwa Play Store — Hausa

A yanzu muna da source code, Firebase scaffold, store listing, privacy policy, da checklist.

Abin da ya rage shi ne a samu computer/build environment domin a yi final Android App Bundle (.aab). Wannan ba zai yiwu daga source zip kawai ba.

Saboda Google Play Console yana bukatar mai developer account ya kasance 18+, babban mutum/trusted adult ne zai kula da Play Console account da verification. Kada a tura password, OTP, private key ko bayanan kati a cikin chat.

Bayan an gina `.aab`:
1. A yi internal/closed testing.
2. Idan sabon personal developer account ne, a bi sharadin closed test na masu gwaji 12 na tsawon kwanaki 14.
3. A nemi production access.
4. Bayan Google ya amince, UK Editing Academy zai bayyana a Play Store.
