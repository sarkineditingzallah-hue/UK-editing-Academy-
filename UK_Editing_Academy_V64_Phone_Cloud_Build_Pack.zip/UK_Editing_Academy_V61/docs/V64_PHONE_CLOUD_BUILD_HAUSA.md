# UK Editing Academy V64 — Phone + Cloud Build

An tsara wannan version ne domin mai amfani ya iya kai aikin zuwa GitHub/Cloud Build daga waya, ba tare da mallakar computer ba.

## Abin da workflow zai yi
1. Ya sauke Flutter.
2. Ya samar da Android project files.
3. Ya sa package ID `com.ukea.app`.
4. Ya gina Debug APK da Debug AAB a **demo mode**.
5. Ya ajiye su a GitHub Actions Artifacts.

## Muhimmi
- Wannan demo build ba ya nufin an haɗa shi da Firebase na production ba.
- Don production Firebase, a samar da ainihin `firebase_options.dart` ta `flutterfire configure` ko a maye gurbin template ɗin da generated file.
- Kada a saka password, OTP, PIN, private key ko bayanan banki cikin repository.
- Domin Play Store production release, sai adult/organization mai shekaru 18+ ya mallaki Google Play developer account kuma a yi signed release AAB.
