# UK Editing Academy — Privacy Policy

**Effective date:** 10 September 2026

UK Editing Academy is an educational app for learning video editing, photo editing, graphic design, AI editing, and TikTok/Reels skills.

## Information we use
- Email address used for account sign-in.
- Name entered for a student profile.
- Learning progress and course-related information stored in the app's Firebase database.

## Passwords
Passwords are handled by Firebase Authentication. UK Editing Academy does not store a user's password in the Firestore student profile.

## How information is used
We use account and learning information to provide sign-in, course access, progress tracking, quizzes, notifications, and certificates.

## Sharing
We do not sell student personal information. Information may be processed by service providers used to operate the app, such as Firebase/Google services.

## Security
We use Firebase Authentication and Firestore security rules. Access permissions are designed so students can access their own account information and authorized app content.

## Children's privacy
The app is intended as an educational service. The publisher should select the correct target-audience settings in Google Play Console and comply with applicable child-safety and privacy requirements.

## Contact
For support, use the official UK Editing Academy support contact supplied in the Google Play listing.
