# UK Editing Academy — Final Play Store Build Checklist

## A. Developer account
1. Google Play Console developer account must be owned by an adult (18+).
2. Use accurate legal identity/contact details.
3. Do not share passwords, OTPs, private keys, or card details with anyone.

## B. App build
1. Complete the Flutter Android project on a computer/build machine.
2. Generate `lib/firebase_options.dart` with FlutterFire for the real Firebase project.
3. Put the real `google-services.json` in `android/app/`.
4. Configure a unique signing key and enable Play App Signing.
5. Set target API level to Android 16 / API 36 for a new app submission.
6. Build a release Android App Bundle (`.aab`).
7. Test login, registration, course screens, lessons, quiz, notifications, certificates, and logout.

## C. Play Console
1. Create the app with package name `com.ukea.app`.
2. Complete Store Listing, App Content, Data Safety, Content Rating, and target-audience declarations.
3. Upload the release AAB.
4. For a new personal developer account created after 13 Nov 2023, run a closed test with at least 12 opted-in testers continuously for 14 days before applying for production access.
5. Apply for production access.
6. After approval, publish to Production.

## Important
The current V61 source is a Firebase-connected scaffold, not a signed production AAB. A computer/build environment is still required to compile the final release.
