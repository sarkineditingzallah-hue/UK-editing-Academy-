import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const bool useFirebase = bool.fromEnvironment('USE_FIREBASE', defaultValue: false);

const navy = Color(0xFF070A12);
const card = Color(0xFF101726);
const blue = Color(0xFF1677FF);
const purple = Color(0xFF7438EF);
const gold = Color(0xFFF3C64B);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (useFirebase) {
    await Firebase.initializeApp();
  }
  runApp(const UkeaApp());
}

class UkeaApp extends StatelessWidget {
  const UkeaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'UK Editing Academy',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: navy,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFF0D1421),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    if (!useFirebase) return const HomePage();
    return StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (_, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Splash();
      return snap.data == null ? const LoginPage() : const HomePage();
    },
  );
}

class Splash extends StatelessWidget { const Splash({super.key});
  @override Widget build(BuildContext c) => const Scaffold(body: Center(child: Text('UK EDITING ACADEMY 👑', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: gold)))); }

class LoginPage extends StatefulWidget { const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController(), password=TextEditingController(); bool busy=false;
  Future<void> login() async { setState(()=>busy=true); try { await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text); } on FirebaseAuthException catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Login failed'))); } finally { if(mounted)setState(()=>busy=false); } }
  Future<void> register() async { setState(()=>busy=true); try { final cred=await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text); await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({'name': email.text.split('@').first,'email':email.text.trim(),'role':'student','createdAt':FieldValue.serverTimestamp()}); } on FirebaseAuthException catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Registration failed'))); } finally { if(mounted)setState(()=>busy=false); } }
  @override Widget build(BuildContext c)=>Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth:430), child: Column(children:[
    Container(width:90,height:90,decoration:BoxDecoration(borderRadius:BorderRadius.circular(26),gradient:const LinearGradient(colors:[blue,purple])),alignment:Alignment.center,child:const Text('UK',style:TextStyle(fontSize:32,fontWeight:FontWeight.w900))),
    const SizedBox(height:18),const Text('UK EDITING ACADEMY 👑',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('Learn • Practice • Create',style:TextStyle(color:gold)),const SizedBox(height:28),
    TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',prefixIcon:Icon(Icons.email_outlined))),const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock_outline))),const SizedBox(height:18),
    SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:login,child:Text(busy?'...':'LOGIN'))),TextButton(onPressed:busy?null:register,child:const Text('CREATE ACCOUNT')),
    const SizedBox(height:8),const Text('Password ɗinka yana cikin Firebase Authentication; ba a adana shi a Firestore.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54,fontSize:12)),
  ]))))));
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage>{ int tab=0; final pages=const [Dashboard(),CoursesPage(),NotificationsPage(),CertificatesPage(),ProfilePage()]; @override Widget build(BuildContext c)=>Scaffold(body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.play_lesson_outlined),label:'Courses'),NavigationDestination(icon:Icon(Icons.notifications_none),label:'Alerts'),NavigationDestination(icon:Icon(Icons.workspace_premium_outlined),label:'Certificates'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile')])); }

class Dashboard extends StatelessWidget { const Dashboard({super.key}); @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[const Text('Assalamu Alaikum 👋',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('UK Editing Academy',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:18),_card('Your Progress','68%',Icons.trending_up),_card('Continue Learning','CapCut Masterclass • Lesson 13',Icons.play_circle_fill),const SizedBox(height:10),const Text('Popular Courses',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),...courseNames.map((x)=>CourseTile(title:x))])); }
Widget _card(String a,String b,IconData i)=>Card(color:card,child:ListTile(leading:CircleAvatar(backgroundColor:blue.withOpacity(.2),child:Icon(i,color:gold)),title:Text(a),subtitle:Text(b),trailing:const Icon(Icons.chevron_right)));

const courseNames=['CapCut Masterclass','Video Editing','Photo Editing','Graphic Design','AI Editing','TikTok & Reels'];
class CoursesPage extends StatelessWidget{const CoursesPage({super.key});@override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[const Text('Courses',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:10),...courseNames.map((x)=>CourseTile(title:x,open:true))]));}
class CourseTile extends StatelessWidget{final String title;final bool open;const CourseTile({super.key,required this.title,this.open=false});@override Widget build(BuildContext c)=>Card(color:card,child:ListTile(leading:const Icon(Icons.video_library,color:gold),title:Text(title),subtitle:const Text('Beginner → Advanced • Practical training'),trailing:open?const Icon(Icons.arrow_forward_ios,size:16):null,onTap:open?()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>CourseDetails(title:title))):null));}
class CourseDetails extends StatelessWidget{final String title;const CourseDetails({super.key,required this.title});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(title)),body:ListView(padding:const EdgeInsets.all(18),children:[const Text('20 Lessons',style:TextStyle(color:gold)),const SizedBox(height:12),...List.generate(20,(i)=>Card(color:card,child:ListTile(leading:CircleAvatar(child:Text('${i+1}')),title:Text(lessonNames[i]),subtitle:Text(i<13?'✓ Completed':'🔒 Locked'),onTap:i<13?()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>LessonPage(title:lessonNames[i],index:i+1))):null)))]));}}
const lessonNames=['Menene Video Editing?','CapCut Interface','Importing Media','Cut & Trim','Text & Captions','Transitions','Audio Editing','Effects','Overlay','Speed Control','Keyframes','Masking','Color Adjustment','Advanced Editing','Final Challenge','Advanced Color Grading','Motion & Animation','Advanced Audio','Portfolio Project','Final Project'];
class LessonPage extends StatelessWidget{final String title;final int index;const LessonPage({super.key,required this.title,required this.index});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text('Lesson $index')),body:ListView(padding:const EdgeInsets.all(18),children:[Text(title,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:16),Container(height:210,decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18)),child:const Center(child:Icon(Icons.play_circle_fill,size:70,color:gold))),const SizedBox(height:14),const Card(color:card,child:Padding(padding:EdgeInsets.all(16),child:Text('What You\'ll Learn\nBrightness, Contrast, Saturation, Temperature, Highlights da Shadows.'))),FilledButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QuizPage())),child:const Text('START QUIZ'))]));}
class QuizPage extends StatefulWidget{const QuizPage({super.key});@override State<QuizPage> createState()=>_QuizPageState();} class _QuizPageState extends State<QuizPage>{bool?done;@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Quiz')),body:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('Menene babban amfani na Color Adjustment?',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:20),...['Ƙara password','Gyara launin video','Buɗe certificate'].map((x)=>Padding(padding:const EdgeInsets.only(bottom:10),child:FilledButton(onPressed:()=>setState(()=>done=x=='Gyara launin video'),child:Text(x)))),if(done!=null)Text(done!?'✅ Correct! Score saved.':'❌ Try again',style:TextStyle(color:done!?Colors.green:Colors.red,fontSize:18))])));}
class NotificationsPage extends StatelessWidget{const NotificationsPage({super.key});@override Widget build(BuildContext c)=>const SafeArea(child:ListView(padding:EdgeInsets.all(18),children:[Text('Notifications',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),Card(color:card,child:ListTile(leading:Icon(Icons.campaign,color:gold),title:Text('Welcome to UK Editing Academy'),subtitle:Text('Za mu sanar da kai idan sabon lesson ya fito.')))]));}
class CertificatesPage extends StatelessWidget{const CertificatesPage({super.key});@override Widget build(BuildContext c)=>const SafeArea(child:ListView(padding:EdgeInsets.all(18),children:[Text('Certificates',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),Card(color:card,child:ListTile(leading:Icon(Icons.workspace_premium,color:gold),title:Text('CapCut Masterclass'),subtitle:Text('UKEA-2026-000001 • Verified'))]));}
class ProfilePage extends StatelessWidget{const ProfilePage({super.key});@override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[const Text('My Profile',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:15),Card(color:card,child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(FirebaseAuth.instance.currentUser?.email??'Student'),subtitle:const Text('Student Account'))),const SizedBox(height:15),OutlinedButton.icon(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout),label:const Text('LOG OUT'))]));}
