# UK Editing Academy — V61 Firebase/Android Setup

## What changed in V61
- Firebase Auth + Firestore app foundation retained.
- Added `firebase.json`.
- Added safer starter `firestore.rules`.
- Added Android/Firebase setup checklist.
- No password, OTP, card PIN, private key, or service-account secret is stored in the app.

## Before building
1. Install Flutter and Android Studio on a computer.
2. In the Firebase project, keep Email/Password Authentication enabled.
3. Firebase Console → Project settings → Your apps → Android app:
   - Package name: `com.ukea.app`
4. Download `google-services.json`.
5. Put it in:
   `android/app/google-services.json`
6. From the project folder run:
   `flutterfire configure`
   This generates the project-specific:
   `lib/firebase_options.dart`
7. Run:
   `flutter pub get`
8. Test:
   `flutter run`
9. Build a test APK:
   `flutter build apk --debug`

## Important security
- Do not put passwords in Firestore.
- Do not put card numbers, PINs, OTPs, or bank credentials in the app source.
- The `role` field in a student's document is not a production admin authorization mechanism.
- For real admin access, use Firebase custom claims or another server-controlled admin allowlist.
- Payment approval and certificate issuance should be trusted-admin/server actions.

## Current limitation
This package is a real Flutter project scaffold, not a compiled APK. A machine with Flutter + Android SDK is required to produce the APK.
