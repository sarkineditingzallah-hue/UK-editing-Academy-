UK EDITING ACADEMY — V63 CLOUD BUILD PACK

This version continues the Play Store preparation from V62.

New work:
1. Cloud Android build workflow added at .github/workflows/android-build.yml
2. Project targets package ID com.ukea.app
3. Workflow builds both debug APK and release AAB
4. Firebase initialization uses native Android configuration
5. Workflow checks for android/app/google-services.json
6. Phone-only cloud-build instructions added in docs/PHONE_CLOUD_BUILD_NEXT_STEP.md

The project is NOT published to Google Play yet.
The final build still needs the Firebase Android configuration file and a cloud build run.
