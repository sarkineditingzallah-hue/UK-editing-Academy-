UK EDITING ACADEMY V64 — PHONE + CLOUD BUILD

An inganta project ɗin domin cloud build. Yanzu workflow yana iya samar da Android project files a GitHub runner sannan ya gina testing APK/AAB a demo mode.

Package ID: com.ukea.app
App name: UK Editing Academy 👑

Next real steps:
1. Put the project in a GitHub repository.
2. Run the Android workflow from Actions.
3. Download the debug APK artifact for testing.
4. Later connect the real Firebase configuration.
5. Prepare a signed release AAB for Play Store under an eligible adult/organization developer account.
